/*
 * Copyright Altera 2013,2015
 * All Rights Reserved
 * File: hello.c
 *
 */

#include <stdio.h>

int main(int argc, char** argv) {
    printf("Hello from Semi-Hosted ARMCC Baremetal Altera SoC-FPGA!\n");
    printf("Wishing you good luck!\n");
    return 0;
}
